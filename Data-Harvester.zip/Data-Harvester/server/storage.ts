import { db } from "./db";
import {
  products,
  type ProductResponse,
  type CreateProductRequest,
  type UpdateProductRequest
} from "@shared/schema";
import { eq, ilike, and } from "drizzle-orm";

export interface IStorage {
  getProducts(search?: string, category?: string): Promise<ProductResponse[]>;
  getProduct(id: number): Promise<ProductResponse | undefined>;
  createProduct(product: CreateProductRequest): Promise<ProductResponse>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(search?: string, category?: string): Promise<ProductResponse[]> {
    let conditions = [];
    
    if (search) {
      conditions.push(ilike(products.title, `%${search}%`));
    }
    
    if (category) {
      conditions.push(eq(products.category, category));
    }
    
    if (conditions.length > 0) {
      return await db.select().from(products).where(and(...conditions));
    }
    
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<ProductResponse | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(product: CreateProductRequest): Promise<ProductResponse> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }
}

export const storage = new DatabaseStorage();