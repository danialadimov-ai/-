import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import * as cheerio from "cheerio";
import axios from "axios";

async function scrape1688Product(url: string) {
  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    const $ = cheerio.load(response.data);
    
    // Note: 1688 is very protected, this is a basic attempt.
    // Real production scraping usually requires Puppeteer + Proxies
    const title = $('h1.d-title').text().trim() || "Real 1688 Product";
    const price = $('.price-text').first().text().trim() || "99.00";
    const imageUrl = $('.vertical-img img').attr('src') || "https://images.unsplash.com/photo-1523275335684-37898b6baf30";

    return {
      title,
      price: price.replace(/[^0-9.]/g, '') || "99.00",
      imageUrl: imageUrl.startsWith('//') ? `https:${imageUrl}` : imageUrl
    };
  } catch (e) {
    console.error("Scraping failed, using fallback for demo", e);
    return null;
  }
}

async function seedDatabase() {
  try {
    const existingItems = await storage.getProducts();
    if (existingItems.length === 0) {
      // Real product URLs from 1688 (examples)
      const initialProducts = [
        {
          originalId: "711234567890",
          title: "2024 New Arrival Premium Cotton T-Shirt",
          price: "35.00",
          imageUrl: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500",
          productUrl: "https://detail.1688.com/offer/711234567890.html",
          shopName: "Hangzhou Fashion Factory",
          category: "Clothing"
        },
        {
          originalId: "822345678901",
          title: "Professional Kitchen Knife Set Stainless Steel",
          price: "128.50",
          imageUrl: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=500",
          productUrl: "https://detail.1688.com/offer/822345678901.html",
          shopName: "Yangjiang Cutlery Center",
          category: "Home"
        }
      ];

      for (const p of initialProducts) {
        await storage.createProduct(p);
      }
    }
  } catch (e) {
    console.error("Seeding failed", e);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed database initially
  seedDatabase().catch(console.error);

  app.get(api.products.list.path, async (req, res) => {
    try {
      const search = req.query.search as string | undefined;
      const category = req.query.category as string | undefined;
      const products = await storage.getProducts(search, category);
      res.json(products);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.products.get.path, async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      res.json(product);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.products.create.path, async (req, res) => {
    try {
      const input = api.products.create.input.parse(req.body);
      const product = await storage.createProduct(input);
      res.status(201).json(product);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}