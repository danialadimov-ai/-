import { useRoute } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { Navbar } from "@/components/layout/Navbar";
import { ArrowLeft, Store, Tag, Link as LinkIcon, ExternalLink, Package, ShieldCheck, Clock } from "lucide-react";
import { Link } from "wouter";

export default function ProductDetail() {
  const [match, params] = useRoute("/product/:id");
  const productId = match && params?.id ? parseInt(params.id, 10) : 0;
  
  const { data: product, isLoading, error } = useProduct(productId);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-8 animate-pulse">
          <div className="h-6 w-32 bg-secondary rounded-md mb-8" />
          <div className="flex flex-col lg:flex-row gap-12">
            <div className="w-full lg:w-1/2 aspect-square bg-secondary rounded-3xl" />
            <div className="w-full lg:w-1/2 space-y-6">
              <div className="h-10 w-full bg-secondary rounded-xl" />
              <div className="h-10 w-2/3 bg-secondary rounded-xl" />
              <div className="h-16 w-1/3 bg-secondary rounded-xl mt-8" />
              <div className="h-12 w-full bg-secondary rounded-xl mt-12" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <Navbar />
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <h2 className="text-2xl font-display font-bold mb-2">Product not found</h2>
          <p className="text-muted-foreground mb-6">The item you requested does not exist or was removed.</p>
          <Link 
            href="/"
            className="px-6 py-3 bg-primary text-primary-foreground font-medium rounded-xl hover:opacity-90 transition-opacity flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" /> Back to Catalog
          </Link>
        </div>
      </div>
    );
  }

  const formattedPrice = Number(product.price).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {/* Breadcrumb / Back */}
        <div className="mb-8">
          <Link 
            href="/"
            className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> 
            Back to Catalog
          </Link>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
          {/* Image Section */}
          <div className="w-full lg:w-[45%]">
            <div className="sticky top-24 rounded-3xl overflow-hidden bg-card border shadow-xl shadow-black/5 aspect-square">
              <img 
                src={product.imageUrl} 
                alt={product.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Details Section */}
          <div className="w-full lg:w-[55%] flex flex-col">
            {/* Badges */}
            <div className="flex flex-wrap gap-2 mb-6">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-secondary text-secondary-foreground text-xs font-semibold uppercase tracking-wider rounded-lg">
                <Tag className="w-3.5 h-3.5" />
                {product.category || "Uncategorized"}
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 text-xs font-semibold uppercase tracking-wider rounded-lg">
                <ShieldCheck className="w-3.5 h-3.5" />
                Verified Listing
              </span>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-display font-bold text-foreground leading-tight mb-6">
              {product.title}
            </h1>

            {/* Price Box */}
            <div className="p-6 bg-card rounded-2xl border shadow-sm mb-8 flex flex-col gap-2">
              <span className="text-sm font-medium text-muted-foreground">Original Price</span>
              <div className="flex items-end gap-2">
                <span className="text-4xl sm:text-5xl font-display font-black text-foreground tracking-tighter">
                  ¥{formattedPrice}
                </span>
                <span className="text-muted-foreground mb-1">RMB</span>
              </div>
            </div>

            {/* Meta Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
              <div className="flex items-start gap-4 p-4 rounded-xl bg-secondary/50 border border-transparent">
                <Store className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">Shop Name</div>
                  <div className="font-semibold text-foreground">{product.shopName || "Unknown Seller"}</div>
                </div>
              </div>

              <div className="flex items-start gap-4 p-4 rounded-xl bg-secondary/50 border border-transparent">
                <Package className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-muted-foreground mb-1">Original ID</div>
                  <div className="font-mono text-sm font-semibold text-foreground break-all">{product.originalId}</div>
                </div>
              </div>
            </div>

            <hr className="border-t border-border mb-8" />

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-4 mt-auto">
              <a 
                href={product.productUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-2 px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-2xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
              >
                <span>View on 1688</span>
                <ExternalLink className="w-5 h-5" />
              </a>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(product.productUrl);
                  // Optional: add a toast here if we had toast integrated, but simple alert suffices for now
                }}
                className="px-8 py-4 bg-card text-foreground font-semibold rounded-2xl border shadow-sm hover:bg-secondary hover:border-border transition-colors flex items-center justify-center gap-2"
              >
                <LinkIcon className="w-5 h-5" />
                Copy Link
              </button>
            </div>
            
            <p className="mt-6 flex items-center justify-center gap-1.5 text-xs text-muted-foreground text-center">
              <Clock className="w-3.5 h-3.5" />
              Prices and availability are scraped directly from the original listing.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
