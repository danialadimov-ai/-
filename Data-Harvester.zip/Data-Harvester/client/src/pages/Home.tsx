import { useState, useEffect } from "react";
import { Search, FilterX, AlertCircle } from "lucide-react";
import { useDebounce } from "use-debounce";
import { useProducts } from "@/hooks/use-products";
import { Navbar } from "@/components/layout/Navbar";
import { ProductCard, ProductCardSkeleton } from "@/components/product/ProductCard";

// Helper list of mock categories to show filter capabilities
const CATEGORIES = [
  "All",
  "Electronics",
  "Clothing",
  "Home & Garden",
  "Toys",
  "Industrial",
];

export default function Home() {
  const [searchInput, setSearchInput] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");
  
  // Debounce search to avoid spamming the API while typing
  const [debouncedSearch] = useDebounce(searchInput, 500);

  const { data: products, isLoading, error } = useProducts({
    search: debouncedSearch || undefined,
    category: activeCategory !== "All" ? activeCategory : undefined,
  });

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />

      <main className="flex-1 w-full max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {/* Page Header & Controls */}
        <div className="mb-10 space-y-6">
          <div className="text-center md:text-left max-w-2xl">
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">
              Explore the Archive
            </h1>
            <p className="text-muted-foreground text-base md:text-lg text-balance">
              Browse thousands of curated items directly sourced from 1688, with real-time pricing and original links.
            </p>
          </div>

          <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-card p-2 rounded-2xl border shadow-sm shadow-black/5">
            {/* Search Input */}
            <div className="relative w-full md:max-w-md flex-1">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-muted-foreground" />
              </div>
              <input
                type="text"
                placeholder="Search products by title..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="block w-full pl-11 pr-4 py-3.5 bg-transparent border-none rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/10 transition-all text-sm font-medium"
              />
            </div>

            {/* Category Pills (Desktop) */}
            <div className="hidden md:flex items-center gap-2 px-2 overflow-x-auto">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`
                    px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all duration-200
                    ${activeCategory === cat 
                      ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                      : "bg-transparent text-muted-foreground hover:bg-secondary hover:text-foreground"
                    }
                  `}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
          
          {/* Category Pills (Mobile Scrollable) */}
          <div className="flex md:hidden items-center gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`
                  px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all
                  ${activeCategory === cat 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-secondary/50 text-muted-foreground border border-transparent"
                  }
                `}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        {error ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <AlertCircle className="w-12 h-12 text-destructive mb-4 opacity-80" />
            <h3 className="text-lg font-display font-semibold">Failed to load products</h3>
            <p className="text-muted-foreground mt-2 max-w-sm">
              There was an error communicating with the database. Please try again later.
            </p>
          </div>
        ) : isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {Array.from({ length: 15 }).map((_, i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : products && products.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-24 text-center bg-card rounded-3xl border border-dashed border-border/60">
            <div className="w-16 h-16 bg-secondary rounded-2xl flex items-center justify-center mb-4">
              <FilterX className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-display font-semibold">No products found</h3>
            <p className="text-muted-foreground mt-2 max-w-sm">
              Try adjusting your search query or changing the category filter to find what you're looking for.
            </p>
            {(searchInput || activeCategory !== "All") && (
              <button 
                onClick={() => { setSearchInput(""); setActiveCategory("All"); }}
                className="mt-6 px-6 py-2.5 bg-secondary hover:bg-secondary/80 text-foreground font-medium rounded-xl transition-colors"
              >
                Clear Filters
              </button>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
