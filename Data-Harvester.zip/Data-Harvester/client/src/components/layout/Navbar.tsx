import { Link } from "wouter";
import { Package, Search, Menu } from "lucide-react";

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full glass-header">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Link 
              href="/" 
              className="flex items-center gap-2 group transition-opacity hover:opacity-80"
            >
              <div className="bg-primary text-primary-foreground p-2 rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <Package className="w-5 h-5" strokeWidth={2.5} />
              </div>
              <span className="font-display font-bold text-xl hidden sm:block">
                Archive<span className="text-muted-foreground">1688</span>
              </span>
            </Link>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-6 text-sm font-medium text-muted-foreground">
              <Link href="/" className="hover:text-primary transition-colors">Catalog</Link>
              <a href="#" className="hover:text-primary transition-colors cursor-not-allowed">Collections</a>
              <a href="#" className="hover:text-primary transition-colors cursor-not-allowed">About</a>
            </div>
            
            <button className="sm:hidden p-2 text-muted-foreground hover:bg-secondary rounded-lg transition-colors">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
