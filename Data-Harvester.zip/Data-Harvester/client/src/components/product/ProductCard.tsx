import { Link } from "wouter";
import { Store, ExternalLink } from "lucide-react";
import { type ProductsListResponse } from "@shared/routes";

type Product = ProductsListResponse[number];

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  // Format price gracefully
  const formattedPrice = Number(product.price).toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return (
    <Link 
      href={`/product/${product.id}`}
      className="group flex flex-col bg-card rounded-2xl border border-border/60 overflow-hidden hover:shadow-xl hover:shadow-primary/5 hover:border-border transition-all duration-300 ease-out hover:-translate-y-1"
    >
      {/* Image Container */}
      <div className="relative aspect-[4/5] bg-secondary/30 overflow-hidden">
        <img 
          src={product.imageUrl} 
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          loading="lazy"
        />
        {/* Subtle overlay gradient on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-sans font-medium text-sm text-foreground line-clamp-2 leading-relaxed mb-2" title={product.title}>
          {product.title}
        </h3>
        
        <div className="mt-auto pt-2 space-y-3">
          <div className="flex items-baseline gap-1">
            <span className="font-display font-bold text-lg text-foreground tracking-tight">
              ¥{formattedPrice}
            </span>
          </div>

          {product.shopName && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Store className="w-3.5 h-3.5" />
              <span className="truncate">{product.shopName}</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="flex flex-col bg-card rounded-2xl border border-border/40 overflow-hidden animate-pulse">
      <div className="aspect-[4/5] bg-secondary" />
      <div className="p-4 flex flex-col gap-3">
        <div className="space-y-2">
          <div className="h-4 bg-secondary rounded-md w-full" />
          <div className="h-4 bg-secondary rounded-md w-2/3" />
        </div>
        <div className="mt-4 space-y-3">
          <div className="h-6 bg-secondary rounded-md w-1/3" />
          <div className="h-4 bg-secondary rounded-md w-1/2" />
        </div>
      </div>
    </div>
  );
}
