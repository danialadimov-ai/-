import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { z } from "zod";

// Helper to log Zod errors nicely
function parseWithLogging<T>(schema: z.ZodSchema<T>, data: unknown, label: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    console.error(`[Zod] ${label} validation failed:`, result.error.format());
    throw result.error;
  }
  return result.data;
}

interface UseProductsParams {
  search?: string;
  category?: string;
}

export function useProducts(params?: UseProductsParams) {
  return useQuery({
    queryKey: [api.products.list.path, params?.search, params?.category],
    queryFn: async () => {
      // Build query string
      const searchParams = new URLSearchParams();
      if (params?.search) searchParams.append("search", params.search);
      if (params?.category) searchParams.append("category", params.category);
      
      const url = `${api.products.list.path}${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
      
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch products");
      
      const data = await res.json();
      return parseWithLogging(api.products.list.responses[200], data, "products.list");
    },
  });
}

export function useProduct(id: number) {
  return useQuery({
    queryKey: [api.products.get.path, id],
    queryFn: async () => {
      if (isNaN(id) || id <= 0) return null;
      
      const url = buildUrl(api.products.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch product");
      
      const data = await res.json();
      return parseWithLogging(api.products.get.responses[200], data, "products.get");
    },
    enabled: !isNaN(id) && id > 0,
  });
}
